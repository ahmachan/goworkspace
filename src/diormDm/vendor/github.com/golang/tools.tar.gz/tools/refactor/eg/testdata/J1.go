// +build ignore

package I1

import "fmt"

func example() {
	temp := 5
	fmt.Print(temp + temp + temp)
}
